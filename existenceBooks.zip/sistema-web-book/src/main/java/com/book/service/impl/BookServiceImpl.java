package com.book.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;

import com.book.commons.GenericServiceImpl;
import com.book.dao.api.BookDaoApi;
import com.book.model.Book;
import com.book.service.api.BookServiceAPI;

public class BookServiceImpl  extends GenericServiceImpl<Book,Long> implements BookServiceAPI{
	
	@Autowired
	private BookDaoApi bookDaoAPI;

	@Override
	public CrudRepository<Book, Long> getDao() {
		return bookDaoAPI;
	}

}
