package com.book.service.api;

import com.book.commons.GenericServiceAPI;
import com.book.model.Book;

public interface BookServiceAPI extends GenericServiceAPI<Book,Long> {

}
