package com.book.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BOOK")
public class Book {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="COD_SUC")
	private Long sucursal;
	
	@Column(name="COD_BOOK")
	private Long codigo;
	
	@Column(name="TITULO")
	private String titulo;
	
	@Column(name="AUTOR")
	private String autor;
	
	@Column(name="CATEGORIA")
	private String categoria;
	
	@Column(name="EDITORIAL")
	private String editorial;
	
	@Column(name="IDIOMA")
	private String idioma;
	
	@Column(name="PAGINAS")
	private Long paginas;
	
	@Column(name="DESCRIPCION")
	private String descripcion;
	
	@Column(name="FECHA_DE_LANZAMIENTO")
	private Date fechadeLanzamiento;
	
	public Book() {
		
	}

	public Book(Long sucursal, Long codigo, String titulo, String autor, String categoria, String editorial,
			String idioma, Long paginas, String descripcion, Date fechadeLanzamiento) {
		//super();
		this.sucursal = sucursal;
		this.codigo = codigo;
		this.titulo = titulo;
		this.autor = autor;
		this.categoria = categoria;
		this.editorial = editorial;
		this.idioma = idioma;
		this.paginas = paginas;
		this.descripcion = descripcion;
		this.fechadeLanzamiento = fechadeLanzamiento;
	}

	public Long getSucursal() {
		return sucursal;
	}

	public void setSucursal(Long sucursal) {
		this.sucursal = sucursal;
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public String getEditorial() {
		return editorial;
	}

	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}

	public String getIdioma() {
		return idioma;
	}

	public void setIdioma(String idioma) {
		this.idioma = idioma;
	}

	public Long getPaginas() {
		return paginas;
	}

	public void setPaginas(Long paginas) {
		this.paginas = paginas;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Date getFechadeLanzamiento() {
		return fechadeLanzamiento;
	}

	public void setFechadeLanzamiento(Date fechadeLanzamiento) {
		this.fechadeLanzamiento = fechadeLanzamiento;
	}

	@Override
	public String toString() {
		return "Book [sucursal=" + sucursal + ", codigo=" + codigo + ", titulo=" + titulo + ", autor=" + autor
				+ ", categoria=" + categoria + ", editorial=" + editorial + ", idioma=" + idioma + ", paginas="
				+ paginas + ", descripcion=" + descripcion + ", fechadeLanzamiento=" + fechadeLanzamiento + "]";
	}
	
}
