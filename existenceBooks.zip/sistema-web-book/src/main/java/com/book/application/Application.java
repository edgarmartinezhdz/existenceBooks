package com.book.application;

import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.book.model.Book;

@SpringBootApplication
public class Application {
	
	private static EntityManager manager;
	
	private static EntityManagerFactory emf;
	
	public static void main(String[] args) {
		
		/* Crear el gestor de persistencia (EM)*/
		
		emf = Persistence.createEntityManagerFactory("Persistencia");
		manager = emf.createEntityManager();
		
		List<Book> book = (List<Book>) manager.createQuery("FROM Book").getResultList();
		
		System.out.println("En esta base de datos hay " + book.size() + " books");
		
		//Book b1 = new Book(25369L,"Edgar","Martinez",new GregorianCalendar(1981,3,6).getTime());
		
		//manager.getTransaction().begin();
		
		//manager.persist(b1);
		
		//manager.getTransaction().commit();
		
		SpringApplication.run(Application.class, args);
		
	}

}
