package com.book.dao.api;

import org.springframework.data.repository.CrudRepository;

import com.book.model.Book;

public interface BookDaoApi extends CrudRepository<Book, Long> {

}
